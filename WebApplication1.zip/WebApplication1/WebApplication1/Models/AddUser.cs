﻿namespace WebApplication1.Models
{
    public class AddUser
    {
        public string FirstName { get; set; }

    }
}
