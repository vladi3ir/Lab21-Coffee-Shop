﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class RegisterViewModel
    {
        public string FirstName { get; set; }
        [Required(ErrorMessage = "Please enter a Name")]
        [RegularExpression(@"^[A-Z]+[a-zA-Z'\s]*$")]
        [StringLength(30)]
        public string LastName { get; set; }
        [RegularExpression(@"^[A-Z]+[a-zA-Z'\s]*$")]
        [Required]
        [StringLength(30)]
        public string Email { get; set; }
        public int PhoneNumber { get; set; }
        public string Password { get; set; }


    }
}
